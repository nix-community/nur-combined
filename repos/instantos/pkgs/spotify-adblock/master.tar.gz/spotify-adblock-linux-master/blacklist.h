static const char *blacklist[] = {
    "https://spclient.wg.spotify.com/ads/*",
    "https://spclient.wg.spotify.com/ad-logic/*",
};
